FALCON TENTS - DEPLOYMENT PACKAGE
================================

Run: node server.js

Port: 3000 (default). Use PORT=8080 node server.js for custom port.

English: /en/homepage | Arabic: /ar/homepage
